﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Property_I_
{
    class Program
    {
        static void Main(string[] args)
        {
            Account account = new Account();
            account.AccountNumber = 10101;
            account.AccountName = "ABC";
            account.Balance = 2000;
            account.BranchName = "Banani";
            //Console.WriteLine("Account Number: "+account.AccountNumber+"\nAccount Name: "+account.AccountName+"\nBalance: "+account.Balance );
            //Console.WriteLine("Account Number: {0}\nAccount Name: {1}\nBalance: {2}",account.AccountNumber,account.AccountName,account.Balance);
            account.PrintAccountDetails();
            Console.WriteLine(account.BranchName);
        }
    }
}
