﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Property_I_
{
    class Account
    {
        //Field declaration
        private int accountNumber;
        private string accountName;
        private double balance;

        //Property declaration
        public int AccountNumber
        {
            set 
            {
                    if(value<0)
                    {
                        this.accountNumber = 0;
                    }
                    else
                    {
                        this.accountNumber = value;
                    }

            }
            get { return this.accountNumber; }
        }
        public string AccountName
        {
            set { this.accountName = value; }
            get { return this.accountName; }
        }
        public double Balance
        {
            set { this.balance = value; }
            get { return this.balance; }
        }
        //Auto-implemented/Automatic Property
        public string BranchName
        {
            set;
            private get;
        }

        //Method declaration
        public void PrintAccountDetails()
        {
            Console.WriteLine("Account Number: {0}\nAccount Name: {1}\nBalance: {2}\nBranch Name: {3}", this.AccountNumber, this.AccountName, this.Balance,this.BranchName);
        }
    }
}
