﻿using System;

namespace Inheritance_IS_A_Relation__I_
{
    class Parent
    {
        public string name="abc";
        virtual public void Method()
        {
            Console.WriteLine("From Class->Parent");
        }
    }
    class Child:Parent
    {
        public string name = "def";
        public string GetParentCopy()
        {
            return base.name;
        }

        //Hiding
        //new public void Method()
        //{
        //    Console.WriteLine("From Class->Child");
        //}

        //Overriding
        //sealed override public void Method()
        override public void Method()
        {
            Console.WriteLine("From Class->Child");
        }
    }
    class GrandChild:Child
    {
        override public void Method()
        {
            Console.WriteLine("From Class->GrandChild");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Child child = new Child();
            //child.Method();
            //Console.WriteLine(child.GetParentCopy());
            //Parent parent = new GrandChild();//upcasting
            //parent.Method();
            //Child child=new Child();
            //child.Method();

            //Polymorphism
            //1. Compile-time-> method overloading
            //2. Runtime-> method overriding
            Parent parent = new GrandChild();//upcasting
            parent.Method();
            parent = new Child();
            parent.Method();
            //Child child = (Child)parent;//downcasting
            //Console.WriteLine(child.GetParentCopy());
            Console.WriteLine(((Child)parent).GetParentCopy());

            
        }
    }
}
