﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Access_Modifiers_I_;
namespace MyLibrary
{
    public class Account
    {
        public Account()
        {
            Person person = new Person();
            person.name = "ABC";
        }
    }
}
