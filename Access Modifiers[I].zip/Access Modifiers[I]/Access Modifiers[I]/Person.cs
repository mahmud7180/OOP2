﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access_Modifiers_I_
{
    public class Person
    {
        public string name;
        private string email;
        protected string address;
        internal string dateOfBirth;
        protected internal int voterId;

        public Person()
        {
            this.name = "ABC";
            this.email = "abc@something.com";
            this.address = "Banani";
            this.dateOfBirth = "1/6/2021";
            this.voterId = 162021;
        }
    }
}
