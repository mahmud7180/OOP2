﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access_Modifiers_I_
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.name = "ABC";
            person.dateOfBirth = "1/6/2021";
            person.voterId = 162021;
        }
    }
}
