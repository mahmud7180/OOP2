﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access_Modifiers_I_
{
    public class Teacher:Person
    {
        public Teacher()
        {
            this.name = "ABC";
            this.address = "Banani";
            this.dateOfBirth = "1/6/2021";
            this.voterId = 162021;
        }
    }
}
