﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstWindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double number1, number2,sum;
        public Form1()
        {
            InitializeComponent();
        }

        private void clickButton_Click(object sender, EventArgs e)
        {
            //clickButton.Text = "Hello";
            //label1.Text = textBox1.Text;

            number1=Convert.ToDouble(textBox1.Text);
            number2 = Convert.ToDouble(textBox2.Text);
            sum = number1 + number2;
           string sum1 = Convert.ToString(sum);
            MessageBox.Show(sum1);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label1.Text = textBox1.Text;

            

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
