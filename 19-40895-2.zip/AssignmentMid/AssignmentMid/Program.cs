﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentMid
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();
            Player player= new Player();
            Manager manager = new Manager();
            EmployeeInformationProvider employeeInformationProvider = new EmployeeInformationProvider();

            employee.Id = "123";
            employee.Name = "Rahim";
            employee.Address = "mithapukur";
            player.Rating = 80;
            employee.PrintInfo();
            employee.EmployeeStatus(80,65);
            player.TotalEarn(65);
            employeeInformationProvider.GetSkilledPlayers();

            employee.Id = "124";
            employee.Name = "Karim";
            employee.Address = "rangpur";
            employee.PrintInfo();
            employee.EmployeeStatus(60, 6);
            player.Rating = 60;
            player.TotalEarn(6);
            employeeInformationProvider.GetSkilledPlayers();

            employee.Id = "125";
            employee.Name = "ankon";
            employee.Address = "dhaka";
            employee.PrintInfo();
            employee.EmployeeStatus(60);
            player.TotalEarn(6);

            employee.Id = "127";
            employee.Name = "sakib";
            employee.Address = "dinajpur";
            employee.PrintInfo();
            employee.EmployeeStatus(2);
            player.TotalEarn(2);





        }
    }
}
