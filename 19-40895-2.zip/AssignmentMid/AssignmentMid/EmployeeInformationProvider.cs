﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentMid
{
    class EmployeeInformationProvider:Player
    {
       
        public void GetSkilledPlayers()
        {
            if (Rating > 80)
            {
                Console.WriteLine("Skilled player");
            }
            else
            {
                Console.WriteLine("Player is not skilled");

            }
        }
    }
}
