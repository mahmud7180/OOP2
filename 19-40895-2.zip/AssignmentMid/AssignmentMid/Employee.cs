﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentMid
{
    class Employee
    {
        string id;
        string name;
        string address;
        
        public string Id
        {
            set { this.id = value; }
            get { return this.id; }
        }

        public string Name
        {
            set { this.name = value; }
            get { return this.name; }
        }

        public string Address
        {
            set { this.address = value; }
            get { return this.address; }
        }

        public void EmployeeStatus(double Rating,int noOfMatch)
        {
            if (Rating > 70 && noOfMatch >= 10)
            {
                Console.WriteLine("The player is eligible for bonus ");

            }
            else
                Console.WriteLine("The player is not eligible for bonus ");

        }

        public void EmployeeStatus(double yearOfExperience)
        {
            if (yearOfExperience > 4 )
            {
                Console.WriteLine("The manager is eligible for bonus ");

            }
            else
                Console.WriteLine("A player is not eligible for bonus ");

        }

        public void PrintInfo()
        {
            Console.WriteLine("Id : " + this.Id + "\nName : " + this.Name + "\nAddress : " + this.Address);
        }


    }
}
