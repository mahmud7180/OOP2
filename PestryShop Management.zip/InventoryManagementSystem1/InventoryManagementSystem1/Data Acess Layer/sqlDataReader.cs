﻿namespace InventoryManagementSystem1.Data_Acess_Layer
{
    internal class sqlDataReader
    {
    }
}