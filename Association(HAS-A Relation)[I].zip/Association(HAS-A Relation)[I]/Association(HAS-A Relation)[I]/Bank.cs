﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Association_HAS_A_Relation__I_
{
    class Bank
    {
        private Account[] accounts;
        public Bank(int size)
        {
            accounts = new Account[size];
        }

        public void AddAccount(Account account)
        {
            bool flag = false;
            for (int i = 0; i < accounts.Length; i++)
            {
                if (accounts[i] == null)
                {
                    accounts[i] = account;
                    flag = true;
                    Console.WriteLine("Account created");
                    break;
                }
                    
            }
            if(!flag)
            {
                Console.WriteLine("Bank is full");
            }
        }

        public void DeleteAccount(int accountNo)
        {
            for(int i=0;i<accounts.Length;i++)
            {
                if(accounts[i].AccountNumber==accountNo)
                {
                    for(int j=i;j<accounts.Length-1;j++)
                    {
                        accounts[j] = accounts[j + 1];
                        accounts[j + 1] = null;
                    }
             
                    Console.WriteLine("Account deleted");
                    break;
                }
            }
        }
        public void PrintAllAccounts()
        {
            for(int i=0;i<accounts.Length;i++)
            {
                if(accounts[i]!=null)
                accounts[i].PrintAccountDetails();

            }
        }
    }
}
