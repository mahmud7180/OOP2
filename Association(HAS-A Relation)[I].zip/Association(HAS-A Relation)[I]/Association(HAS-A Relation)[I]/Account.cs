﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Association_HAS_A_Relation__I_
{
    class Account
    {
        //Field declaration
        private int accountNumber;
        private string accountName;
        private double balance;
        private Address address;

        public Account(int accountNumber,string accountName,double balance,string branch,Address address)
        {
            this.accountNumber = accountNumber;
            this.accountName = accountName;
            this.balance = balance;
            this.BranchName = branch;
            this.address = address;
        }
        //Property declaration
        public int AccountNumber
        {
            set 
            {
                    if(value<0)
                    {
                        this.accountNumber = 0;
                    }
                    else
                    {
                        this.accountNumber = value;
                    }

            }
            get { return this.accountNumber; }
        }
        public string AccountName
        {
            set { this.accountName = value; }
            get { return this.accountName; }
        }
        public double Balance
        {
            set { this.balance = value; }
            get { return this.balance; }
        }
        public Address Address
        {
            set { this.address = value; }
            get { return this.address; }
        }
        //Auto-implemented/Automatic Property
        public string BranchName
        {
            set;
            get;
        }

        //Method declaration
        public void PrintAccountDetails()
        {
            Console.WriteLine("Account Number: {0}\nAccount Name: {1}\nBalance: {2}\nBranch Name: {3}", this.AccountNumber, this.AccountName, this.Balance,this.BranchName);
            Console.WriteLine(address.GetAddress());
            Console.WriteLine("==============================================");
        }
    }
}
