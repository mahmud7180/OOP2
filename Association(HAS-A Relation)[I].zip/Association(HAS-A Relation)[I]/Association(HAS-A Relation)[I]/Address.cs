﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Association_HAS_A_Relation__I_
{
    class Address
    {
        private string houseNo, roadNo, area;

        public Address(string houseNo,string roadNo,string area)
        {
            this.houseNo = houseNo;
            this.roadNo = roadNo;
            this.area = area;
        }
        public string HouseNo
        {
            set { this.houseNo = value; }
            get { return this.houseNo; }
        }
        public string RoadNo
        {
            set { this.roadNo = value; }
            get { return this.roadNo; }
        }
        public string Area
        {
            set { this.area = value; }
            get { return this.area; }
        }

        public string GetAddress()
        {
            return "Address: House no:" + this.houseNo + ", Road no:" + this.roadNo + ", Area:" + this.area;
              
        }
    }
}
