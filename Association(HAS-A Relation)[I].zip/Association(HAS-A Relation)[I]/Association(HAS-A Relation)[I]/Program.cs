﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Association_HAS_A_Relation__I_
{
    class Program
    {
        static void Main(string[] args)
        {
            Address address = new Address("14/A","7","Banani");
            Account account = new Account(1011,"Shakib",2000,"Gulshan",address);
            //account.PrintAccountDetails();
            
            Account account1 = new Account(2022, "Tamim", 3000, "Uttara", new Address("10", "5/C", "Kuril"));
            //account1.PrintAccountDetails();
            //Console.WriteLine(account1.Address.GetAddress()); ;

            Bank bank = new Bank(5);
            bank.AddAccount(account);
            //bank.AddAccount(account1);
            bank.AddAccount(account);
            //bank.AddAccount(account1);
            bank.AddAccount(account);
            //bank.AddAccount(account1);
            bank.DeleteAccount(2022);
            bank.PrintAllAccounts();
        }
    }
}
